import React, { useState } from 'react';
import './App.css';

function Detect() {
  const [selectedFile, setSelectedFile] = useState(null);
  const [isFilePicked, setIsFilePicked] = useState(false);
  const [predUrl, setPredUrl] = useState();
  const [srcUrl, setSrcUrl] = useState();
  const [side1Url, setSide1Url] = useState();
  const [side2Url, setSide2Url] = useState();
  const [side3Url, setSide3Url] = useState();
  const [side4Url, setSide4Url] = useState();
  const [side5Url, setSide5Url] = useState();
  const [fusedUrl, setFusedUrl] = useState();
  const [unit, setImgUnit] = useState('m');
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  const changeHandler = (event) => {
    const file = event.target.files[0];
    setSelectedFile(file);
    setIsFilePicked(true);

    if (file) {
      const url = URL.createObjectURL(file);
      setSrcUrl(url);

      const img = new Image();
      img.onload = () => {
        setDimensions({
          width: img.naturalWidth,
          height: img.naturalHeight
        });
      };
      img.src = url;
    }
  };

  const setUnit = (event) => setImgUnit(event.target.value);

  const handleSubmit = event => {
    event.preventDefault();
    const formData = new FormData();
    formData.append("file", selectedFile, selectedFile.name);

    const requestOptions = {
      method: 'POST',
      body: formData,
    };

    fetch(`http://127.0.0.1:8000/predict/${dimensions.width}-${dimensions.height}/${unit}`, requestOptions)
      .then(response => response.json())
      .then(data => {
        setPredUrl(`data:image/png;base64,${data[0]}`);
        setFusedUrl(`data:image/png;base64,${data[1]}`);
        setSide1Url(`data:image/png;base64,${data[2]}`);
        setSide2Url(`data:image/png;base64,${data[3]}`);
        setSide3Url(`data:image/png;base64,${data[4]}`);
        setSide4Url(`data:image/png;base64,${data[5]}`);
        setSide5Url(`data:image/png;base64,${data[6]}`);
      })
      .catch((err) => console.log(err));
  }

  return (
    <div className="app-container">
      <div className="main-layout">
        {/* Left Sidebar - Upload Panel */}
        <div className="upload-panel">
          <div className="panel-header">
            <h2>
              <span className="icon">📤</span>
              Image Upload
            </h2>
          </div>
          <form onSubmit={handleSubmit} className="upload-form">
            <div className="form-group">
              <label>Select Image</label>
              <div className="file-input-container">
                <input 
                  type="file" 
                  onChange={changeHandler} 
                  accept=".jpeg, .png, .jpg"
                  className="file-input"
                  id="fileInput"
                />
                <label htmlFor="fileInput" className="file-input-label">
                  {selectedFile ? selectedFile.name : "Choose a file"}
                </label>
              </div>
            </div>

            <div className="form-group">
              <label>Image Dimensions</label>
              <div className="dimension-display">
                {dimensions.width} × {dimensions.height} px
              </div>
            </div>

            <div className="form-group">
              <label>Measurement Unit</label>
              <input 
                type="text" 
                placeholder="e.g., m, cm, mm" 
                onChange={setUnit}
                className="unit-input"
              />
            </div>

            <button 
              type="submit" 
              disabled={!isFilePicked}
              className="predict-button"
            >
              <span className="icon">🔍</span>
              Analyze Image
            </button>
          </form>
        </div>

        {/* Main Content Area */}
        <div className="content-area">
          <div className="main-header">
            <h1>
              <span className="decorator">✦</span>
              DeepCrack Analysis Dashboard
              <span className="decorator">✦</span>
            </h1>
          </div>
          
          {/* Image Comparison Section */}
          <div className="image-comparison">
            <div className="source-image-container">
              <div className="image-card">
                <div className="card-header primary">
                  <span className="icon">🖼️</span>
                  Original Image
                </div>
                <div className="card-body">
                  {srcUrl ? (
                    <>
                      <img src={srcUrl} alt="Original" className="preview-image" />
                      <div className="dimension-badge">
                        {dimensions.width} × {dimensions.height} px
                      </div>
                    </>
                  ) : (
                    <div className="image-placeholder">
                      <span className="icon">📷</span>
                      <p>No image selected</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="prediction-container">
              <div className="image-card main-prediction">
                <div className="card-header success">
                  <span className="icon">🔎</span>
                  Crack Detection Results
                </div>
                <div className="card-body">
                  {predUrl ? (
                    <>
                      <img src={predUrl} alt="Prediction" className="prediction-image" />
                      <div className="prediction-badge">
                        Analysis Complete
                      </div>
                    </>
                  ) : (
                    <div className="prediction-placeholder">
                      <span className="icon">✨</span>
                      <p>Upload and analyze an image</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Intermediate Predictions */}
          <div className="intermediate-predictions">
            <div className="section-header">
              <h3>
                <span className="icon">🧩</span>
                Feature Maps
              </h3>
            </div>
            <div className="feature-grid">
              {[side1Url, side2Url, side3Url, side4Url, side5Url].map((url, index) => (
                <div key={index} className="feature-card">
                  <div className="feature-image-container">
                    {url ? (
                      <img src={url} alt={`Feature ${index+1}`} className="feature-image" />
                    ) : (
                      <div className="feature-placeholder">
                        <span className="icon">🔍</span>
                      </div>
                    )}
                  </div>
                  <div className="feature-label">Layer {index+1}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Fused Prediction */}
          <div className="fused-prediction">
            <div className="section-header">
              <h3>
                <span className="icon">🧬</span>
                Fused Prediction
              </h3>
            </div>
            <div className="fused-image-container">
              {fusedUrl ? (
                <img src={fusedUrl} alt="Fused Prediction" className="fused-image" />
              ) : (
                <div className="fused-placeholder">
                  <span className="icon">🔄</span>
                  <p>Combined analysis will appear here</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Detect;