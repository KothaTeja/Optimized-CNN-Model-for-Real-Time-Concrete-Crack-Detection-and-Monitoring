import React from 'react';
import './App.css';
import { Link } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      {/* Hero Section */}
      <header className="hero">
        <div className="container">
          <h1>AI-Powered Concrete Crack Detection</h1>
          <p className="lead">
            Advanced deep learning solution for automated crack detection and analysis in concrete structures
          </p>
          <div className="cta-buttons">
            <Link to='/detect'> <button className="btn btn-primary">Analyse cracks</button></Link>
            
          </div>
        </div>
      </header>

      {/* About Section */}
      <section className="about-section">
        <div className="container">
          <h2>About Our Technology</h2>
          <div className="about-content">
            <div className="about-text">
              <p>
                Our crack detection system uses a PyTorch implementation of DeepCrack, a deep hierarchical feature learning architecture 
                for crack segmentation based on Holistically-Nested Edge Detection (HED) from ICCV 2015.
              </p>
              <p>
                The model was trained on a dataset of 40,000 concrete images (227×227 pixels) collected from METU Campus Buildings, 
                with equal distribution of positive and negative crack examples.
              </p>
              <a href="https://github.com/yhlleo/DeepCrack/blob/master/paper/DeepCrack-Neurocomputing-2019.pdf" 
                 className="btn btn-outline" target="_blank" rel="noopener noreferrer">
                Read Research Paper
              </a>
            </div>
            <div className="about-image">
              <img 
                src="https://github.com/yhlleo/DeepCrack/blob/master/figures/architecture.jpg?raw=true" 
                alt="DeepCrack Architecture" 
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section">
        <div className="container">
          <h2>Key Features</h2>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">📊</div>
              <h3>Accurate Segmentation</h3>
              <p>Precisely identifies crack boundaries using advanced CNN architecture</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">📏</div>
              <h3>Dimensional Analysis</h3>
              <p>Measures crack length, width, and calculates area of damage</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">🏗️</div>
              <h3>Structural Assessment</h3>
              <p>Classifies crack severity for maintenance prioritization</p>
            </div>
          </div>
        </div>
      </section>

      {/* Results Section */}
      <section className="results-section">
        <div className="container">
          <h2>Detection Results</h2>
          <div className="results-gallery">
            <div className="result-item">
              <img 
                src="https://user-images.githubusercontent.com/46296774/103016160-edd0b180-4541-11eb-8cfe-3c7680569eb9.PNG" 
                alt="Crack Detection Example 1" 
              />
              <p>Original image with detected cracks</p>
            </div>
            <div className="result-item">
              <img 
                src="https://user-images.githubusercontent.com/46296774/103016173-f4f7bf80-4541-11eb-9bb5-933dcd725d9b.PNG" 
                alt="Crack Detection Example 2" 
              />
              <p>Segmentation mask overlay</p>
            </div>
            <div className="result-item">
              <img 
                src="https://user-images.githubusercontent.com/46296774/177764562-f7ed470d-22b9-4e13-b5a0-74254b54b841.png" 
                alt="Detailed Analysis Output" 
              />
              <p>Detailed crack measurements</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="container">
          <h2>Ready to Analyze Your Structures?</h2>
          <p>
            Upload images of concrete surfaces and get instant crack analysis with detailed reports
          </p>
        </div>
      </section>


      <footer className="footer">
        <div className="container">
          <p>Concrete Crack Detection System © {new Date().getFullYear()}</p>
          <p>
            Based on research from <a href="https://github.com/yhlleo/DeepCrack" target="_blank" rel="noopener noreferrer">DeepCrack</a> | 
            Dataset from <a href="https://data.mendeley.com/datasets/5y9wdsg2zt/2" target="_blank" rel="noopener noreferrer">METU Campus Buildings</a>
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;